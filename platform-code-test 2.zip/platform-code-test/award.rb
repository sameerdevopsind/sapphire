Award = Struct.new(:name, :expires_in, :quality)
